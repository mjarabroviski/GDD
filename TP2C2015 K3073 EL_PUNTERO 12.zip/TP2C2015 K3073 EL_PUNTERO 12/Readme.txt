CURSO:		K3073	
NRO DE GRUPO:	12
INTEGRANTES: 	Melanie Jarabroviski	149.254-8
		Iara Edelstein 		149.321-8
		Matias Girard 		149.249-4
		Luciano Garofalo	149.251-2
RESPONSABLE: 	melaniejarabroviski@hotmail.com
