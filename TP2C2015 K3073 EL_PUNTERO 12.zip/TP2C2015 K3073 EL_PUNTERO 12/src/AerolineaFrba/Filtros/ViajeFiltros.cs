﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Filtros
{
    public class ViajeFiltros
    {
        public DateTime FechaSalida { get; set; }
        public string CiudadOrigen { get; set; }
        public string CiudadDestino { get; set; }
    }
}
