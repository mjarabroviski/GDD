﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Filtros
{
    public class CiudadFiltros
    {
        public string Nombre { get; set; }
    }
}
