﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Filtros
{
    public class EstadisticaFiltros
    {
        public string FechaDesde { get; set; }

        public string FechaHasta { get; set; }
    }
}
