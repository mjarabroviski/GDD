﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Filtros
{
    public class EstadisticaFiltros
    {
        public DateTime FechaDesde { get; set; }

        public DateTime FechaHasta { get; set; }
    }
}
