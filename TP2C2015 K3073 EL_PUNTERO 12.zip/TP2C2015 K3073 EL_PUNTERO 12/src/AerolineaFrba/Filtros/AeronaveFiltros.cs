﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Filtros
{
    public class AeronaveFiltros
    {
        public string Matricula { get; set; }
        public string Fabricante { get; set; }
        public string Modelo { get; set; }
        public string Servicio { get; set; }
        public DateTime Fecha_Alta { get; set; }
    }
}
