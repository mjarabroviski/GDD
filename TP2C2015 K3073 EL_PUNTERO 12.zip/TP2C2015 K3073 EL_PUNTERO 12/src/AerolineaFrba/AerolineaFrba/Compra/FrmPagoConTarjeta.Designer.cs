﻿namespace AerolineaFrba.Compra
{
    partial class FrmPagoConTarjeta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtTitular = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.CmbTipoTarjeta = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TxtNroTarjeta = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.TxtMes = new System.Windows.Forms.TextBox();
            this.TxtAnio = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.TxtCodigoSeguridad = new System.Windows.Forms.TextBox();
            this.BtnTarjeta = new System.Windows.Forms.Label();
            this.BtnCancelar = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.CmbCantCuotas = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 16);
            this.label1.TabIndex = 99;
            this.label1.Text = "Ingrese los datos de la tarjeta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(92, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 100;
            this.label2.Text = "Titular";
            // 
            // TxtTitular
            // 
            this.TxtTitular.Enabled = false;
            this.TxtTitular.Location = new System.Drawing.Point(134, 39);
            this.TxtTitular.Name = "TxtTitular";
            this.TxtTitular.Size = new System.Drawing.Size(178, 20);
            this.TxtTitular.TabIndex = 101;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label4.Location = new System.Drawing.Point(117, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 20);
            this.label4.TabIndex = 104;
            this.label4.Text = "*";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CmbTipoTarjeta
            // 
            this.CmbTipoTarjeta.FormattingEnabled = true;
            this.CmbTipoTarjeta.Location = new System.Drawing.Point(134, 75);
            this.CmbTipoTarjeta.Name = "CmbTipoTarjeta";
            this.CmbTipoTarjeta.Size = new System.Drawing.Size(178, 21);
            this.CmbTipoTarjeta.TabIndex = 103;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 102;
            this.label3.Text = "Tipo Tarjeta";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label5.Location = new System.Drawing.Point(117, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 20);
            this.label5.TabIndex = 106;
            this.label5.Text = "*";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 13);
            this.label6.TabIndex = 105;
            this.label6.Text = "Número Tarjeta";
            // 
            // TxtNroTarjeta
            // 
            this.TxtNroTarjeta.Location = new System.Drawing.Point(134, 110);
            this.TxtNroTarjeta.Name = "TxtNroTarjeta";
            this.TxtNroTarjeta.Size = new System.Drawing.Size(178, 20);
            this.TxtNroTarjeta.TabIndex = 107;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label7.Location = new System.Drawing.Point(117, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 20);
            this.label7.TabIndex = 109;
            this.label7.Text = "*";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 146);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 13);
            this.label8.TabIndex = 108;
            this.label8.Text = "Fecha de Vencimiento";
            // 
            // TxtMes
            // 
            this.TxtMes.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.TxtMes.Location = new System.Drawing.Point(134, 143);
            this.TxtMes.Name = "TxtMes";
            this.TxtMes.Size = new System.Drawing.Size(25, 20);
            this.TxtMes.TabIndex = 110;
            this.TxtMes.Text = "MM";
            this.TxtMes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtMes.Click += new System.EventHandler(this.TxtMes_Click);
            this.TxtMes.TextChanged += new System.EventHandler(this.TxtMes_TextChanged);
            // 
            // TxtAnio
            // 
            this.TxtAnio.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.TxtAnio.Location = new System.Drawing.Point(174, 143);
            this.TxtAnio.Name = "TxtAnio";
            this.TxtAnio.Size = new System.Drawing.Size(38, 20);
            this.TxtAnio.TabIndex = 111;
            this.TxtAnio.Text = "AAAA";
            this.TxtAnio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtAnio.Click += new System.EventHandler(this.TxtAnio_Click);
            this.TxtAnio.TextChanged += new System.EventHandler(this.TxtAnio_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(161, 143);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 20);
            this.label9.TabIndex = 112;
            this.label9.Text = "/";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label10.Location = new System.Drawing.Point(117, 173);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 20);
            this.label10.TabIndex = 114;
            this.label10.Text = "*";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 178);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(106, 13);
            this.label11.TabIndex = 113;
            this.label11.Text = "Código de Seguridad";
            // 
            // TxtCodigoSeguridad
            // 
            this.TxtCodigoSeguridad.Location = new System.Drawing.Point(134, 175);
            this.TxtCodigoSeguridad.Name = "TxtCodigoSeguridad";
            this.TxtCodigoSeguridad.Size = new System.Drawing.Size(78, 20);
            this.TxtCodigoSeguridad.TabIndex = 115;
            // 
            // BtnTarjeta
            // 
            this.BtnTarjeta.BackColor = System.Drawing.Color.DodgerBlue;
            this.BtnTarjeta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BtnTarjeta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnTarjeta.ForeColor = System.Drawing.Color.White;
            this.BtnTarjeta.Location = new System.Drawing.Point(224, 241);
            this.BtnTarjeta.Name = "BtnTarjeta";
            this.BtnTarjeta.Size = new System.Drawing.Size(88, 43);
            this.BtnTarjeta.TabIndex = 117;
            this.BtnTarjeta.Text = "CONFIRMAR COMPRA";
            this.BtnTarjeta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BtnTarjeta.Click += new System.EventHandler(this.BtnTarjeta_Click);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackColor = System.Drawing.Color.DodgerBlue;
            this.BtnCancelar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BtnCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnCancelar.ForeColor = System.Drawing.Color.White;
            this.BtnCancelar.Location = new System.Drawing.Point(18, 241);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(88, 43);
            this.BtnCancelar.TabIndex = 116;
            this.BtnCancelar.Text = "CANCELAR";
            this.BtnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label12.Location = new System.Drawing.Point(117, 206);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 20);
            this.label12.TabIndex = 119;
            this.label12.Text = "*";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 211);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 13);
            this.label13.TabIndex = 118;
            this.label13.Text = "Cantidad de Cuotas";
            // 
            // CmbCantCuotas
            // 
            this.CmbCantCuotas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCantCuotas.FormattingEnabled = true;
            this.CmbCantCuotas.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "6",
            "12"});
            this.CmbCantCuotas.Location = new System.Drawing.Point(134, 208);
            this.CmbCantCuotas.Name = "CmbCantCuotas";
            this.CmbCantCuotas.Size = new System.Drawing.Size(78, 21);
            this.CmbCantCuotas.TabIndex = 120;
            // 
            // FrmPagoConTarjeta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(326, 302);
            this.ControlBox = false;
            this.Controls.Add(this.CmbCantCuotas);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.BtnTarjeta);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.TxtCodigoSeguridad);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TxtAnio);
            this.Controls.Add(this.TxtMes);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.TxtNroTarjeta);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.CmbTipoTarjeta);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TxtTitular);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPagoConTarjeta";
            this.Text = "Pago Con Tarjeta de Credito";
            this.Load += new System.EventHandler(this.FrmPagoConTarjeta_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtTitular;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox CmbTipoTarjeta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TxtNroTarjeta;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TxtMes;
        private System.Windows.Forms.TextBox TxtAnio;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox TxtCodigoSeguridad;
        private System.Windows.Forms.Label BtnTarjeta;
        private System.Windows.Forms.Label BtnCancelar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox CmbCantCuotas;
    }
}