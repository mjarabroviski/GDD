﻿namespace AerolineaFrba.Registro_Llegada_Destino
{
    partial class InformacionAeronave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Txt_Matricula = new System.Windows.Forms.TextBox();
            this.Txt_Fabricante = new System.Windows.Forms.TextBox();
            this.Txt_Modelo = new System.Windows.Forms.TextBox();
            this.Txt_TipoServicio = new System.Windows.Forms.TextBox();
            this.Txt_BajaFuera = new System.Windows.Forms.TextBox();
            this.Txt_BajaVidaUtil = new System.Windows.Forms.TextBox();
            this.Txt_FechaBajaDef = new System.Windows.Forms.TextBox();
            this.Txt_FechaAlta = new System.Windows.Forms.TextBox();
            this.Txt_KG = new System.Windows.Forms.TextBox();
            this.BtnAgregarFecha = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Btn_Volver = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "MATRICULA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "FABRICANTE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "MODELO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "TIPO SERVICIO";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "BAJA POR VIDA UTIL";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 206);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(133, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "FECHA BAJA DEFINITIVA";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 233);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "FECHA ALTA";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 259);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "KG TOTALES";
            // 
            // Txt_Matricula
            // 
            this.Txt_Matricula.Enabled = false;
            this.Txt_Matricula.Location = new System.Drawing.Point(188, 37);
            this.Txt_Matricula.Name = "Txt_Matricula";
            this.Txt_Matricula.Size = new System.Drawing.Size(164, 20);
            this.Txt_Matricula.TabIndex = 10;
            // 
            // Txt_Fabricante
            // 
            this.Txt_Fabricante.Enabled = false;
            this.Txt_Fabricante.Location = new System.Drawing.Point(188, 65);
            this.Txt_Fabricante.Name = "Txt_Fabricante";
            this.Txt_Fabricante.Size = new System.Drawing.Size(164, 20);
            this.Txt_Fabricante.TabIndex = 11;
            // 
            // Txt_Modelo
            // 
            this.Txt_Modelo.Enabled = false;
            this.Txt_Modelo.Location = new System.Drawing.Point(188, 92);
            this.Txt_Modelo.Name = "Txt_Modelo";
            this.Txt_Modelo.Size = new System.Drawing.Size(164, 20);
            this.Txt_Modelo.TabIndex = 12;
            // 
            // Txt_TipoServicio
            // 
            this.Txt_TipoServicio.Enabled = false;
            this.Txt_TipoServicio.Location = new System.Drawing.Point(188, 121);
            this.Txt_TipoServicio.Name = "Txt_TipoServicio";
            this.Txt_TipoServicio.Size = new System.Drawing.Size(164, 20);
            this.Txt_TipoServicio.TabIndex = 13;
            // 
            // Txt_BajaFuera
            // 
            this.Txt_BajaFuera.Enabled = false;
            this.Txt_BajaFuera.Location = new System.Drawing.Point(188, 147);
            this.Txt_BajaFuera.Name = "Txt_BajaFuera";
            this.Txt_BajaFuera.Size = new System.Drawing.Size(164, 20);
            this.Txt_BajaFuera.TabIndex = 15;
            // 
            // Txt_BajaVidaUtil
            // 
            this.Txt_BajaVidaUtil.Enabled = false;
            this.Txt_BajaVidaUtil.Location = new System.Drawing.Point(188, 173);
            this.Txt_BajaVidaUtil.Name = "Txt_BajaVidaUtil";
            this.Txt_BajaVidaUtil.Size = new System.Drawing.Size(164, 20);
            this.Txt_BajaVidaUtil.TabIndex = 16;
            // 
            // Txt_FechaBajaDef
            // 
            this.Txt_FechaBajaDef.Enabled = false;
            this.Txt_FechaBajaDef.Location = new System.Drawing.Point(188, 199);
            this.Txt_FechaBajaDef.Name = "Txt_FechaBajaDef";
            this.Txt_FechaBajaDef.Size = new System.Drawing.Size(164, 20);
            this.Txt_FechaBajaDef.TabIndex = 17;
            // 
            // Txt_FechaAlta
            // 
            this.Txt_FechaAlta.Enabled = false;
            this.Txt_FechaAlta.Location = new System.Drawing.Point(188, 226);
            this.Txt_FechaAlta.Name = "Txt_FechaAlta";
            this.Txt_FechaAlta.Size = new System.Drawing.Size(164, 20);
            this.Txt_FechaAlta.TabIndex = 18;
            // 
            // Txt_KG
            // 
            this.Txt_KG.Enabled = false;
            this.Txt_KG.Location = new System.Drawing.Point(188, 252);
            this.Txt_KG.Name = "Txt_KG";
            this.Txt_KG.Size = new System.Drawing.Size(164, 20);
            this.Txt_KG.TabIndex = 19;
            // 
            // BtnAgregarFecha
            // 
            this.BtnAgregarFecha.BackColor = System.Drawing.Color.DodgerBlue;
            this.BtnAgregarFecha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BtnAgregarFecha.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnAgregarFecha.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarFecha.Location = new System.Drawing.Point(188, 297);
            this.BtnAgregarFecha.Name = "BtnAgregarFecha";
            this.BtnAgregarFecha.Size = new System.Drawing.Size(106, 39);
            this.BtnAgregarFecha.TabIndex = 92;
            this.BtnAgregarFecha.Text = "AGREGAR FECHA LLEGADA";
            this.BtnAgregarFecha.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BtnAgregarFecha.Click += new System.EventHandler(this.BtnAgregarFecha_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(169, 13);
            this.label6.TabIndex = 96;
            this.label6.Text = "BAJA POR FUERA DE SERVICIO";
            // 
            // Btn_Volver
            // 
            this.Btn_Volver.BackColor = System.Drawing.Color.DodgerBlue;
            this.Btn_Volver.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Btn_Volver.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Volver.ForeColor = System.Drawing.Color.White;
            this.Btn_Volver.Location = new System.Drawing.Point(75, 297);
            this.Btn_Volver.Name = "Btn_Volver";
            this.Btn_Volver.Size = new System.Drawing.Size(106, 39);
            this.Btn_Volver.TabIndex = 97;
            this.Btn_Volver.Text = "VOLVER";
            this.Btn_Volver.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Btn_Volver.Click += new System.EventHandler(this.Btn_Volver_Click_1);
            // 
            // InformacionAeronave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 345);
            this.ControlBox = false;
            this.Controls.Add(this.Btn_Volver);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.BtnAgregarFecha);
            this.Controls.Add(this.Txt_KG);
            this.Controls.Add(this.Txt_FechaAlta);
            this.Controls.Add(this.Txt_FechaBajaDef);
            this.Controls.Add(this.Txt_BajaVidaUtil);
            this.Controls.Add(this.Txt_BajaFuera);
            this.Controls.Add(this.Txt_TipoServicio);
            this.Controls.Add(this.Txt_Modelo);
            this.Controls.Add(this.Txt_Fabricante);
            this.Controls.Add(this.Txt_Matricula);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "InformacionAeronave";
            this.Text = "Informacion de Aeronave";
            this.Load += new System.EventHandler(this.InformacionAeronave_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Txt_Matricula;
        private System.Windows.Forms.TextBox Txt_Fabricante;
        private System.Windows.Forms.TextBox Txt_Modelo;
        private System.Windows.Forms.TextBox Txt_TipoServicio;
        private System.Windows.Forms.TextBox Txt_BajaFuera;
        private System.Windows.Forms.TextBox Txt_BajaVidaUtil;
        private System.Windows.Forms.TextBox Txt_FechaBajaDef;
        private System.Windows.Forms.TextBox Txt_FechaAlta;
        private System.Windows.Forms.TextBox Txt_KG;
        private System.Windows.Forms.Label BtnAgregarFecha;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Btn_Volver;

    }
}